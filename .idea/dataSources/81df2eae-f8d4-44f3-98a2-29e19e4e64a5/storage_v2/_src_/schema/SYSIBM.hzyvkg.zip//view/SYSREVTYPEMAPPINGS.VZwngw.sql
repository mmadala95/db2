create view sysibm.sysrevtypemappings 
(type_mapping, typeschema, typename, typeid, sourcetypeid, 
definer, lower_len, upper_len, lower_scale, upper_scale, 
s_opr_p, bit_data, wrapname, 
servername, servertype, serverversion, remote_typeschema, 
remote_typename, remote_meta_type, remote_length, 
remote_scale, 
remote_bit_data, user_defined, create_time, 
remarks) 
as select 
type_mapping, typeschema, typename, typeid, sourcetypeid, definer, 
lower_len, upper_len, lower_scale, upper_scale, s_opr_p, bit_data, 
wrapname, servername, servertype, serverversion, remote_typeschema, 
remote_typename, remote_meta_type, remote_lower_len, remote_lower_scale, 
remote_bit_data, user_defined, create_time, remarks 
from sysibm.systypemappings
;

