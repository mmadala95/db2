create view sysibm.dual (dummy) as values (char('X'))
;

