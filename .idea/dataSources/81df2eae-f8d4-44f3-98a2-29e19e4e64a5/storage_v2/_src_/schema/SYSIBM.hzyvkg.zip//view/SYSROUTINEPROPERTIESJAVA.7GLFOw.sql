create view sysibm.sysroutinepropertiesjava 
(routine_id, class, jar_id, jarschema, jar_signature) 
as select 
routine_id, class, jar_id, jarschema, jar_signature 
from sysibm.sysroutineproperties
;

