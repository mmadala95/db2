create view sysibm.sysfuncparms 
(fname, fschema, fspecific, rowtype, ordinal, 
typename, typeschema, length, scale, codepage, cast_function_id, 
parmname, as_locator, target_typeschema, target_typename, 
scope_tabschema, scope_tabname, transform_grpname) 
as select 
routinename, routineschema, specificname, rowtype, ordinal, 
typename, typeschema, length, scale, codepage, cast_function_id, 
parmname, locator, target_typeschema, target_typename, 
scope_tabschema, scope_tabname, transform_grpname 
from sysibm.sysroutineparms 
where routinetype in ('F', 'M') 
and routineschema not in ('SYSIBMINTERNAL')
;

