create view sysibm.sysprocedures 
(procschema, procname, specificname, procedure_id, definer, 
parm_count, parm_signature, origin, create_time, fenced, 
nullcall, language, implementation, parm_style, result_sets, remarks, 
deterministic, packed_desc, contains_sql, dbinfo, program_type, 
valid, class, jar_id, text_body_offset, text) 
as select 
a.routineschema, a.routinename, a.specificname, a.routine_id, a.definer, 
a.parm_count, a.parm_signature, a.origin, a.createdts, a.fenced, 
a.null_call, a.language, a.implementation, a.parameter_style, 
a.result_sets, a.remarks, a.deterministic, a.internal_desc, 
a.sql_data_access, a.dbinfo, a.program_type, a.valid, 
CASE 
WHEN a.language <> 'JAVA' THEN NULL 
ELSE 
(SELECT pj.class 
FROM SYSIBM.SYSROUTINEPROPERTIES AS pj 
WHERE pj.routine_id = a.routine_id) 
END, 
CASE 
WHEN a.language <> 'JAVA' THEN NULL 
ELSE 
(SELECT pj.jar_id 
FROM SYSIBM.SYSROUTINEPROPERTIES AS pj 
WHERE pj.routine_id = a.routine_id) 
END, 
a.text_body_offset, a.text 
from sysibm.sysroutines as a 
where a.routinetype in ('P') 
and a.routineschema not in ('SYSIBMINTERNAL')
;

