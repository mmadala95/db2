create view sysibm.sysdummy1 (ibmreqd) as values (char('Y'))
;

