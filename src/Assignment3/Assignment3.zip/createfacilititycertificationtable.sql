DROP TABLE cse532.facilitycertification;

CREATE TABLE cse532.facilitycertification(
FacilityID VARCHAR(16) ,
FacilityName VARCHAR(256),
Description VARCHAR (256),
AttributeType VARCHAR (32),
AttributeValue VARCHAR (128),
MeasureValue VARCHAR (16),
County VARCHAR (32)
);