load from "/database/Downloads/nyzip.csv"
of del modified by DATEFORMAT="MMDDYYYY"  MESSAGES load.msg INSERT INTO CSE532.ZIPPOP;